#ifndef __Timer0_H___
#define __Timer0_H___

void Timer0Init(void);	
#endif