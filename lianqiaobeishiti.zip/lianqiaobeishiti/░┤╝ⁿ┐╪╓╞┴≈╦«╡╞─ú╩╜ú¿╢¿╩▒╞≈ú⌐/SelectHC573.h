#ifndef __SelectHC573_H___
#define __SelectHC573_H___

void SelectH573(unsigned char channel);
#endif