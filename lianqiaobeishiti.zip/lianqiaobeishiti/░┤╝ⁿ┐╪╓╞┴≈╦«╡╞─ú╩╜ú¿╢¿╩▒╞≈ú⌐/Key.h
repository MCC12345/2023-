#ifndef __Key_H___
#define __Key_H___

unsigned char Key(void);
#endif