#include <REGX52.H>
#include"Delay.H"
#include"SelectHC573.H"
#include"Key.H"
#include"Timer0.H"
#include <INTRINS.H>

unsigned char KeyNum,Model;

void main()
{
	SelectH573(4);
	P0=0xFE;
	Timer0Init();
	
	while(1)
	{
		KeyNum=Key();
		if(KeyNum)
		{
			if(KeyNum==1)
			{
       		Model++;
				if(Model>=2)
					Model=0;
			}
		
		}
		
	}
}



void Timer0_Routine()  interrupt 1
{
static unsigned int Count;
	TL0 = 0x66;		
	TH0 = 0xFC;
	Count++;
	if(Count>=500)
	{
	Count=0;
		if(Model==0)
		{
			SelectH573(4);
			P0=_crol_(P0,1);
		}
		if(Model==1)
		{
			SelectH573(4);
			P0=_cror_(P0,1);
		}
	}
}