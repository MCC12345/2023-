#include <REGX52.H>

code unsigned char NixieTable[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x83,0xc6,0xa1,0x86,0x8e};


void SelectHC573(unsigned char n)
{
	switch(n)
	{
		case 4:
			P2 = (P2 & 0x1f) | 0x80;
		break;
		case 5:
			P2 = (P2 & 0x1f) | 0xa0;
		break;
		case 6:
			P2 = (P2 & 0x1f) | 0xc0;
		break;
		case 7:
			P2 = (P2 & 0x1f) | 0xe0;
		break;
		case 0:
			P2 = (P2 & 0x1f) | 0x00;
		break;
	}
}

void Nixie(unsigned char Location,Number)
{
	SelectHC573(6);
	P0=Location;
	SelectHC573(7);
	P0=NixieTable[Number];
	
	
}


void main()
{
	SelectHC573(4);
	P0=0xff;
	 Nixie(0x01,8);
	while(1)
	{
	
	}
}