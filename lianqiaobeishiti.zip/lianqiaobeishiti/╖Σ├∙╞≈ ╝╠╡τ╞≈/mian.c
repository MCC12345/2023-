#include <REGX52.H>



void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}


void SelectHC573(unsigned char channel)
{
	switch(channel)
	{
		case 4:
			P2=(P2&0x1f)|0x80;
		break;
		case 5:
			P2=(P2&0x1f)|0xa0;
		break;
		case 6:
			P2=(P2&0x1f)|0xc0;
		break;
		case 7:
			P2=(P2&0x1f)|0xe0;
		break;
		
	}
}
void main()
{
	SelectHC573(5);
	
	
	while(1)
	{
		P0_6=0;
		Delay(500);
//  	P0_6=1;
//	  P0_4=1;
		Delay(500);
		P0_4=0;
		
	}
}