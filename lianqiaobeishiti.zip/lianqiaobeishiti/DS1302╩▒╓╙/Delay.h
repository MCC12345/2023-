#ifndef __Delay_H___
#define __Delay_H___

void Delay(unsigned char xms);
#endif


