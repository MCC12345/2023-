#include <REGX52.H>
#include "DS1302.H"
#include "Nixie.H"
#include "Delay.H"
void main()
{
	DS1302_Init();
	DS1302_SetTime();
	Delay(10);

	while(1)
	{
			DS1302_ReadTime();
		SMG_show(0x01,DS1302_Time[3]/10);
		SMG_show(0x02,DS1302_Time[3]%10);
		SMG_show(0x08,DS1302_Time[4]/10);
		SMG_show(0x10,DS1302_Time[4]%10);
		SMG_show(0x40,DS1302_Time[5]/10);
		SMG_show(0x80,DS1302_Time[5]%10);
	
	}
}
	
	