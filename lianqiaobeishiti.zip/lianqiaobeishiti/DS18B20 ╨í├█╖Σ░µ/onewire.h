#ifndef __onewire_H___
#define __onewire_H___

bit init_ds18b20(void);
void Write_DS18B20(unsigned char dat);
unsigned char Read_DS18B20(void);
#endif