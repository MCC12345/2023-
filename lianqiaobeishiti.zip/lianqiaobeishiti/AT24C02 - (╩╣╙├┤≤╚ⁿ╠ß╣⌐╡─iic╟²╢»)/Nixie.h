#ifndef __Nixie_H___
#define __Nixie_H___

void SMG_show(unsigned char Location,Number);
#endif