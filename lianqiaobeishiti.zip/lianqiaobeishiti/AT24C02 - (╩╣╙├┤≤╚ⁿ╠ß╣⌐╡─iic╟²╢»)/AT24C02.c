#include <REGX52.H>
#include "iic.H"

#define AT24C02_ADDRESS    0xA0

void AT24C02_WriteByte(unsigned char WordAddress,Data)
{
	I2CStart();
	I2CSendByte(AT24C02_ADDRESS);
	I2CWaitAck();
	I2CSendByte(WordAddress);
	I2CWaitAck();
	I2CSendByte(Data);
	I2CWaitAck();
	I2CStop();
}

unsigned char AT24C02_ReadByte(unsigned char WordAddress)
{
	unsigned char Data;
	I2CStart();
	I2CSendByte(AT24C02_ADDRESS);
	I2CWaitAck();
	I2CSendByte(WordAddress);
	I2CWaitAck();
	I2CStart();
	I2CSendByte(AT24C02_ADDRESS|0x01);
	I2CWaitAck();
	Data=I2CReceiveByte();
	I2CSendAck(1);
	I2CStop();
	return Data;
}