#ifndef   __Delay_H__
#define   __Delay_H__

void Delay(unsigned int xms);	
	
#endif