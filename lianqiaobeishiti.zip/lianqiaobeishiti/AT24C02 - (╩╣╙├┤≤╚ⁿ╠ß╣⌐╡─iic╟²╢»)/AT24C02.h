#ifndef __AT24C02_H___
#define __AT24C02_H___

void AT24C02_WriteByte(unsigned char WordAddress,Data);
unsigned char AT24C02_ReadByte(unsigned char WordAddress);
#endif