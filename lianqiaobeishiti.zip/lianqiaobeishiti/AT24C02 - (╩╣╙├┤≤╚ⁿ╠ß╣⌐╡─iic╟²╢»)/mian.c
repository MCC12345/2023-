#include <REGX52.H>
#include "AT24C02.H"
#include "Nixie.H"
#include "Delay.H"
void main()
{
	unsigned char Temp=8,con;
	
//  AT24C02_WriteByte(0,Temp);
	
  con=AT24C02_ReadByte(0);
	SMG_show(0x01,con);
	while(1)
	{
	


	}
}