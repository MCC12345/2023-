#ifndef __SelectHC573_H___
#define __SelectHC573_H___

void SelectHC573(unsigned char channel);
#endif