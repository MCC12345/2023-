#ifndef __UART_H___
#define __UART_H___

void UartInit(void);
void UART_SendByte(Byte);
#endif