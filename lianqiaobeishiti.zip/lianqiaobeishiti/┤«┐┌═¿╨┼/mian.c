#include <REGX52.H>
#include"SelectHC573.H"
#include"UART.H"
#include"Delay.H"


void main()
{
	UartInit();
	
	while(1)
	{

		
	}
}


void UART_Routine()  interrupt 4
{
	
	if(RI==1)
	{
		SelectHC573(4);
		P0=SBUF;
			UART_SendByte(SBUF);
		RI=0;
		
	}
	
}