#include <REGX52.H>
#include "onewire.h"
#include "Nixie.h"
float temp_ds18b20 = 0;          //实际温度值
unsigned int smg_ds18b20 = 0;    


void DisplaySMG_Temp()
{
 smg_ds18b20 = temp_ds18b20 * 100;
      SMG_show(0x08,smg_ds18b20  % 10);
      SMG_show(0x04,(smg_ds18b20 / 10) % 10);    
      SMG_show(0x02,(smg_ds18b20 / 100) % 10);
      if(smg_ds18b20 / 1000 != 0)
      {
        SMG_show(0x01,smg_ds18b20 / 1000);
      }
}		
void Read_Dsiplay_DS18B20()
{
  unsigned char LSB,MSB;      
  unsigned int temp = 0;      
  
  init_ds18b20();              //初始化DS18B20
  DisplaySMG_Temp();          //动态刷新数码管    
  Write_DS18B20(0xcc);        //忽略ROM操作
  Write_DS18B20(0x44);        //启动温度转换
  DisplaySMG_Temp();          //动态刷新数码管
  init_ds18b20();              //初始化DS18B20
  DisplaySMG_Temp();          //动态刷新数码管
  Write_DS18B20(0xcc);        //忽略ROM操作
  Write_DS18B20(0xbe);        //读出内部存储器
  LSB = Read_DS18B20();        //第0字节：温度低8位
  MSB = Read_DS18B20();        //第1字节：温度高8位
  DisplaySMG_Temp();          //动态刷新数码管
  //上述程序中插入多处数码管刷新，可使显示亮度充足
  temp = MSB;                  //合成16位温度原始数据
  temp = (temp << 8) | LSB;
  if((temp & 0xf800) == 0x0000)    //处理正温度
  {
    temp_ds18b20 = temp * 0.0625;  //计算实际温度值
  }
  DisplaySMG_Temp();          //动态刷新数码管
}