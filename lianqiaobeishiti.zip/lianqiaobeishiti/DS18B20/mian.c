#include <REGX52.H>
#include "DS18B20.H"
#include "Delay.H"
#include "Nixie.H"
#include "onewire.h"


void main()
{
	 init_ds18b20();              
         
  Write_DS18B20(0xcc);        
  Write_DS18B20(0x44); 
	Delay(1500);
	
	
	while(1)
	{
Read_Dsiplay_DS18B20();
		
		
	}
}
