#ifndef __DS18B20_H__
#define __DS18B20_H__

void Read_Dsiplay_DS18B20();
#endif
