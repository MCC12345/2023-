#ifndef __MatrixKey_H__
#define __MatrixKey_H__

unsigned char MatrixKey(void);
#endif