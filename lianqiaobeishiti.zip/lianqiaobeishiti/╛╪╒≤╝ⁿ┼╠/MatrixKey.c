#include <REGX52.H>
#include"Delay.H"

sfr P4= 0xC0;
sbit P4_4=0xc4;
sbit P4_2=0xc2;

unsigned char MatrixKey(void)
{
	unsigned char KeyNumber=0;
	P3=0xff;
	P4=0xff;
	P3_0=0;
	if(P4_4==0){Delay(20);while(P4_4==0);Delay(20);KeyNumber=1;}
	if(P4_2==0){Delay(20);while(P4_2==0);Delay(20);KeyNumber=2;}
	if(P3_5==0){Delay(20);while(P3_5==0);Delay(20);KeyNumber=3;}
	if(P3_4==0){Delay(20);while(P3_4==0);Delay(20);KeyNumber=4;}
	
	P3=0xff;
	P4=0xff;
	P3_1=0;
	if(P4_4==0){Delay(20);while(P4_4==0);Delay(20);KeyNumber=5;}
	if(P4_2==0){Delay(20);while(P4_2==0);Delay(20);KeyNumber=6;}
	if(P3_5==0){Delay(20);while(P3_5==0);Delay(20);KeyNumber=7;}
	if(P3_4==0){Delay(20);while(P3_4==0);Delay(20);KeyNumber=8;}
	
	P3=0xff;
	P4=0xff;
	P3_2=0;
	if(P4_4==0){Delay(20);while(P4_4==0);Delay(20);KeyNumber=9;}
	if(P4_2==0){Delay(20);while(P4_2==0);Delay(20);KeyNumber=10;}
	if(P3_5==0){Delay(20);while(P3_5==0);Delay(20);KeyNumber=11;}
	if(P3_4==0){Delay(20);while(P3_4==0);Delay(20);KeyNumber=12;}
	
	P3=0xff;
	P4=0xff;
	P3_3=0;
	if(P4_4==0){Delay(20);while(P4_4==0);Delay(20);KeyNumber=13;}
	if(P4_2==0){Delay(20);while(P4_2==0);Delay(20);KeyNumber=14;}
	if(P3_5==0){Delay(20);while(P3_5==0);Delay(20);KeyNumber=15;}
	if(P3_4==0){Delay(20);while(P3_4==0);Delay(20);KeyNumber=16;}
	
	return KeyNumber;
}