#include <REGX52.H>
#include"Delay.H"
#include"MatrixKey.H"
#include"Nixie.H"
#include"SelectHC573.H"


sbit P4_4=0xc4;
sbit P4_2=0xc2;


unsigned char KeyNumber,KeyNum,Temp;
void main()
{
	unsigned con;
	
	while(1)
	{
		KeyNumber=MatrixKey();
		
		if(KeyNumber==1)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==2)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==3)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==4)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==5)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==6)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==7)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==8)
		{
		SMG_show(0x01,KeyNumber);
		}
		if(KeyNumber==9)
		{
		SMG_show(0x01,KeyNumber);
		}
			
			if(KeyNumber==10)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		if(KeyNumber==11)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		if(KeyNumber==12)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		if(KeyNumber==13)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		if(KeyNumber==14)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		if(KeyNumber==15)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		if(KeyNumber==16)
		{
			con=1;
			while(con)
			{
			SMG_show(0x01,KeyNumber/10);	
			SMG_show(0x02,KeyNumber%10);
				P3_0=0;P3_1=0;P3_2=0;P3_3=0;
				if(P3_4==0||P3_5==0||P4_2==0||P4_4==0)
					con=0;
			}
		}
		
		
	}

	}