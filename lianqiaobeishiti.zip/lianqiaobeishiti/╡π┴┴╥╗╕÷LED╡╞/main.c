#include "REGX52.H"


void Delayxms(unsigned char xms);

void SelectHC573(unsigned char channel)
{
	switch(channel)
	{
		case 4:
			P2=(P2&0x1f)|0x80;
					break;
		case 5:
			P2=(P2&0x1f)|0xa0;
		     break;
		case 6:
			P2=(P2&0x1f)|0xc0;
		     break;
		case 7:
			P2=(P2&0x1f)|0xe0;
		     break;
		case 8:
			P2=(P2&0x1f)|0x00;
				 break;
					
	}
}



void main()
{
	
	while(1)
	{
SelectHC573(4);
	
	   P0=0xFE;
		 Delay1ms(500);
		P0=0xFF;
		Delay1ms(500);
	}
}

void Delayxms(unsigned char xms)		//@11.0592MHz
{
	unsigned char i, j;

	while(xms)
	{
	i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
	xms--;
}
}


