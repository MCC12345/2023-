#include <REGX52.H>
#include "iic.h"
#include "Delay.H"

unsigned char ADC_ReadValue(void)
{
	unsigned char Data=0;
	I2CStart();
	I2CSendByte(0x90);
	I2CWaitAck();
	I2CSendByte(0x03);
	I2CWaitAck();

	
	I2CStart();
	I2CSendByte(0x91);
	I2CWaitAck();
	Data=I2CReceiveByte();
	I2CSendAck(1);
	I2CStop();
	return Data;
}
