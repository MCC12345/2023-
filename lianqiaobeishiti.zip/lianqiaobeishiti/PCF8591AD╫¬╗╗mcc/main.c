#include <REGX52.H>
#include "PCF8591.h"
#include "Nixie.h"


unsigned char Num;
unsigned char Number;


void main()
{

	while(1)
	{
    Num= ADC_ReadValue();
		Number=(int)(Num/255.0*5*100);
  
		SMG_show(0x01,Number / 100);
 		SMG_show(0x02,Number/ 10% 10);
		SMG_show(0x04,Number  % 10);
		
	}
	
}
