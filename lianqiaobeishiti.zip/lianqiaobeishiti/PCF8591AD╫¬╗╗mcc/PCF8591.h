#ifndef __PCF8591_H__
#define __PCF8591_H__

unsigned char ADC_ReadValue(void);

#endif
